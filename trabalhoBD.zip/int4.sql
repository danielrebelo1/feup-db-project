.mode columns
.headers on
.nullvalue NULL

select c1.nome , c2.nome 
from 